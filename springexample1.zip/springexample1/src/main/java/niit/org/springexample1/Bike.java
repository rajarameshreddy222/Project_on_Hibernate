package niit.org.springexample1;




public class Bike implements Vechile
{

	public void move()
	{
		System.out.println("Bike Started");
		
	}

}
