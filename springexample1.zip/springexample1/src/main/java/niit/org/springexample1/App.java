package niit.org.springexample1;


public class App 
{
    public  void choice(Vechile vechile)
    {
     
    	vechile.move();
    }
}
