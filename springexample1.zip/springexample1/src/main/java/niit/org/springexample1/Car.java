package niit.org.springexample1;

public class Car implements Vechile
{

	public void move()
	{
	System.out.println("Car Started");	
	}

	
	
}
