package niit.org.springexample1;

public interface Vechile
{

	void move();
	
}
