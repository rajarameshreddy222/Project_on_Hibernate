package niit.org.springexample2;

public interface Vehicle
{

	void move();
	
}
