package niit.org.springexample2;



import org.springframework.stereotype.Component;

@Component
public class Bike implements Vehicle
{

	public void move()
	{
		System.out.println("Bike Started");
		
	}

}
