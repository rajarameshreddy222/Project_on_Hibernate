package rrr.groups.spring_example_on_objectinjection;

public class Students 
{

	private Student s1;
	private Student s2;
	private Student s3;
	private Student s4;
	
	
	public Student getS1() {
		return s1;
	}
	public void setS1(Student s1) {
		this.s1 = s1;
	}
	public Student getS2() {
		return s2;
	}
	public void setS2(Student s2) {
		this.s2 = s2;
	}
	public Student getS3() {
		return s3;
	}
	public void setS3(Student s3) {
		this.s3 = s3;
	}
	public Student getS4() {
		return s4;
	}
	public void setS4(Student s4) {
		this.s4 = s4;
	}
	@Override
	public String toString() {
		return "Students [s1=" + s1.getName() + ", s2=" + s2.getName() + ", s3=" + s3.getName() + ", s4=" + s4.getName() + "]";
	}
	
	
	
	
}
