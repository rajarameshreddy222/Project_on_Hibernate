package model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Bill
{@Id
 @GeneratedValue
 private String oid;
 private String cname;
 private int countitems;
 private Double totalbill;
public String getOid() {
	return oid;
}
public void setOid(String oid) {
	this.oid = oid;
}
public String getCname() {
	return cname;
}
public void setCname(String cname) {
	this.cname = cname;
}
public int getCountitems() {
	return countitems;
}
public void setCountitems(int countitems) {
	this.countitems = countitems;
}
public Double getTotalbill() {
	return totalbill;
}
public void setTotalbill(Double totalbill) {
	this.totalbill = totalbill;
}
 
}
