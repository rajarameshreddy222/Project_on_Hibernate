package dao;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.Date;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import model.Orders;
import model.Product;
import model.User;

public class Daoimple implements Dao
{
	SessionFactory sf=null;
	
	
	public Daoimple()
	{
		Configuration cfg=new Configuration().configure().addAnnotatedClass(User.class).addAnnotatedClass(Product.class).addAnnotatedClass( Orders.class);
		sf=cfg.buildSessionFactory();
		
	}
	
	static Connection con=null;
	public static Connection  getConnectionObject() 
    {
	   		
	     return con;	
    }


	
	
	

	public boolean register(User u)
	{
		boolean b=false;
		
		Object  obj=null;
          
        	  if(u.getUtype().equals("reqempreg"))
      		{
        		
               Session session=sf.openSession();
               Transaction tx=session.beginTransaction();
              session.save(u);
              tx.commit();
		     session.close();
      		}
        	  
        	else if (u.getUtype().equals("reqcusreg"))
      		{
        	 Session session=sf.openSession();
               Transaction tx=session.beginTransaction();
               session.save(u);
               tx.commit();
       		   session.close();
        	}
      return b;
	 }
	
	
	public boolean login(User u)
	{
		boolean b=false;
		
	    ArrayList<User> al=new ArrayList<User>();
		
		if(u.getUtype().equals("reqemplogin"))
		{
			
			 Session session=sf.openSession();
			 al=(ArrayList<User>) session.createQuery(" from User where  utype='reqempreg' and email='"+u.getEmail()+"' and pwd='"+u.getPwd()+"' ").list();
			System.out.println(al);
			 if(al.size()!=0)   // number of elements in al !=0 k sir
			{
				b=true;
			}
			 session.close();
			
		}
		else if(u.getUtype().equals("reqcuslogin"))
		{ 
			System.out.println("usertype   "+u.getUtype());
			Session session=sf.openSession();
			// u=(User)session.get(User.class, u.getEmail());
			/// u=(User)session.createQuery(" from User where utype='"+u.getUtype()+"'");
			
			 al=(ArrayList<User>) session.createQuery(" from User where  utype='reqcusreg' and email='"+u.getEmail()+"' and pwd='"+u.getPwd()+"' ").list();
				if(al.size()!=0)
				{
					b=true;
				}			
			 session.close();			
		}	
	   
		return b;
		
	}
	
	public boolean forgot(User u) 
	{
		boolean b=false;
     	if(u.getUtype().equals("reqempreg"))
		{
		Session session=sf.openSession();
	
		User u1=new User();
		u1=(User)session.get(User.class, u.getEmail());
		u1.setPwd(u.getPwd());
		session.close();
		Session session1=sf.openSession();
		Transaction tx=session1.beginTransaction();
		session.update(u1);
		tx.commit();
		session1.close();
			
		}
		else if(u.getUtype().equals("reqcusreg"))
		{
			Session session=sf.openSession();
			User u1=new User();
			u1=(User)session.get(User.class, u.getEmail());
			u1.setPwd(u.getPwd());
			session.close();
			Session session1=sf.openSession();
			Transaction tx=session1.beginTransaction();
			session1.update(u1);
			tx.commit();
			session1.close();
		}
		
		b=true;
	    return b;
	 }
	
    public User cusviewbyid(User u) 
	{
		Session session=sf.openSession();
		u=(User)session.get(User.class, u.getEmail());
		session.close();
	     return u;
	}
	
	public User empviewbyid(User u) 
	{
		Session session=sf.openSession();
		u=(User)session.get(User.class, u.getEmail());
		session.close();
	    return u;
	}
	
	public boolean updateCus(User u)
	{
		boolean b=false;
	    Session session=sf.openSession();
		Transaction tx=session.beginTransaction();
		session.update(u);
		tx.commit();
		session.close();
		return b;
	}



	public boolean addProduct(Product p) 
	{
		boolean b=false;

		Date d=new Date();
		java.sql.Date d1=new java.sql.Date(d.getYear(),d.getMonth(),d.getDate());
		p.setTdate(d1.toString());
        Session session1=sf.openSession();
        Transaction tx=session1.beginTransaction();
        session1.save(p);
        tx.commit();
	    session1.close();
		return b;
	 }


	public ArrayList<Product> viewallproduct(Product p)
	{
		
		Session session=sf.openSession();
        ArrayList<Product> al=new ArrayList<Product>();
		al=(ArrayList<Product>)session.createQuery("from Product");
		session.close();
		return al;
	}


	public ArrayList<Product> searchProduct(Product p) 
	{
		ArrayList<Product> al=new ArrayList<Product>();
		Session session=sf.openSession();
		al=(ArrayList<Product>)session.createQuery(" from Product where pname like '%"+p.getPname().toLowerCase()+"%'").list();               
		session.close();
		return al;
	}
	
	public ArrayList<Product> searchProduct(Product p,String req) 
	{
		ArrayList<Product> al=new ArrayList<Product>();
		
		   if(req.equals("lh"))
		   {Session session=sf.openSession();
			   al=(ArrayList<Product>)session.createQuery("from Product where pname like '%"+p.getPname().toLowerCase()+"%' order by pprice asc").list();
		   }
		   else if(req.equals("hl"))
		   {Session session=sf.openSession();
			   al=(ArrayList<Product>)session.createQuery("from Product where pname like '%"+p.getPname().toLowerCase()+"%' order by pprice desc").list();
		   }
			
		return al;
		
	}

	public Product productInfoByPid(Product p)
	{
		Session session=sf.openSession();
		p=(Product)session.get(Product.class,p.getPid());
		session.close();
		
       return p;
	}


	public boolean addproducttocart(Orders o,String name) 
	{
	   boolean b=false;
	   Date d=new Date();
       java.sql.Date d1=new java.sql.Date(d.getYear(),d.getMonth(),d.getDate());
       o.setOdate(d1.toString());
     
        
       o.setCname(name);
       o.setTprice((o.getPprice())*(o.getPqty()));
       Session session=sf.openSession();
       Transaction tx=session.beginTransaction();
       session.save(o);
       tx.commit();
       session.close();
       return b;
	}


	public void addTOCart(Product p)
	{
		
		
	}


	public ArrayList<Orders> viewproductfromcart(String name)
	{   Orders o=new Orders();
        o.setCname(name);
	    ArrayList<Orders> al=new ArrayList<Orders>();
		Session session=sf.openSession();
		al=(ArrayList<Orders>)session.createQuery("from Orders where cname='"+o.getCname()+"'").list();

		
		session.close();
		return al;
	}


	
	
	public Orders sumoftotal(String name)
	 
	{
		boolean b=false;
		Orders o=new Orders();
		Session session=sf.openSession();
		
		
		
		
	   ResultSet rs=null;
	con=getConnectionObject();
	try {
		Statement ps=con.createStatement();
		 rs=ps.executeQuery(" select count(*),sum(tprice) from orders11 where cname='"+name+"'  ");
		 
		if(rs.next())
		{ 
		//	o.setCount(rs.getInt(1));
		//	o.setSumoftotal(rs.getDouble(2));
			
			
			
	    }
		
				
	} catch (SQLException e) {
		
		e.printStackTrace();
	}
	
	
		return o ;
	
	}

	
	
	
	
	

	

	public boolean addproducttocart1(Product p, String name)
	{
		
		
		/// in these method presentday and after 3days date  i need 
    //		now() and now()+3 it is not working sir 
		
		
		  ///Query q=session.createQuery("insert into orders values(now(),now()+3);k sir 
	       
		
		
		boolean b=false;
		  User u=new User();  
		  ArrayList<Product> al=new ArrayList<Product>();
		    ResultSet rs=null;
	        Date d=new Date();
		     java.sql.Date d1=new java.sql.Date(d.getYear(),d.getMonth(),d.getDate());
		  //   java.sql.Date d2=new java.sql.Date(d.getYear(),d.getMonth(),d.getDate());
			con=getConnectionObject();
			try {
				Statement st=con.createStatement();
				rs=st.executeQuery("select * from orders11 where cname='"+name+"'");
				while(rs.next())
				{ Product p1=new Product();
					p1.setFilename(rs.getString(1));
					p1.setPid(rs.getString(2));
					p1.setPname(rs.getString(3));
					p1.setPprice(rs.getDouble(4));
					p1.setPqty(rs.getInt(5));
					//p1.setTprice(rs.getDouble(6));
					al.add(p1);
				}
				
				for(Product p1:al)
				{
					Statement stmt=con.createStatement();
				int i=	stmt.executeUpdate("insert into orders12( FILENAME , 	PID , 	PNAME  ,	PPRICE,PQTY    ,	TPRICE  ,	CNAME  ,	ODATE,ddate) values('"+p1.getFilename()+"','"+p1.getPid()+"','"+p1.getPname()+"','"+p1.getPprice()+"','"+p1.getPqty()+"','"+(p1.getPprice()*p1.getPqty())+"','"+name+"',now(),now()+5)");                                     
		
				if(i>0)
				{
			
				int j=st.executeUpdate("delete from orders11 where cname='"+name+"'");
				if(j>0)
				{
					b=true;
				}
				
					
				}
				}
				
				
			} catch (SQLException e) {
				
				e.printStackTrace();
			}
			
			
			return b;
		
	
	}


	public ArrayList<Product> viewproductfromMyOrders(String name) {
		
		ResultSet rs=null;
		ArrayList<Product> al=new ArrayList<Product>();
		con=getConnectionObject();
		try {
			Statement ps=con.createStatement();
			 rs=ps.executeQuery(" select FILENAME,PID,PNAME,PPRICE,PQTY,TPRICE from orders12 where cname='"+name+"' ");
			while(rs.next())
			{
				
				Product p=new Product();
				
				p.setFilename(rs.getString(1));
				p.setPid(rs.getString(2));
				p.setPname(rs.getString(3));
				p.setPprice(rs.getDouble(4));
				p.setPqty(rs.getInt(5));
		   ///	p.setTprice(rs.getDouble(6));
				al.add(p);
          }
			
					
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		
		return al;
	}



	
	
	
	
	
	
	

}
